package com.Kaleidofin.aadharRedaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AadharRedactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(AadharRedactionApplication.class, args);
	}

}
