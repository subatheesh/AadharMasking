package com.kaleidofin.nachvalidation;

public class Snippet {
	public static void main(String[] args) {
		
	}
}

